/*
 * Custom Cortex-M3 portmacro.h for this project, overriding the stock
 * FreeRTOS-Kernel/portable/GCC/ARM_CM3/portmacro.h via include-path
 * priority (this file lives in the project's own include/ folder, which
 * PlatformIO searches before library folders).
 *
 * WHY THIS EXISTS:
 * Wokwi's Cortex-M3 emulation does not correctly handle an exception
 * self-pended by a store to ICSR (how the stock port requests PendSV for
 * every context switch): the pending store re-executes forever instead of
 * completing and returning. This makes the stock port hang the instant a
 * real context switch is needed, with no crash and no fault -- just a
 * silent infinite loop (confirmed: CPU usage stays non-zero, LED heartbeat
 * never runs, no HardFault, no assert).
 *
 * This port never uses PendSV. Context switches happen synchronously
 * inside the SVC handler (voluntary yields, portYIELD()) and inside the
 * SysTick handler (tick-driven preemption) -- both of which were confirmed
 * to behave correctly. Critical sections use PRIMASK (cpsid/cpsie), not
 * BASEPRI, since BASEPRI masking appears to be a no-op in Wokwi's NVIC
 * (this also explains a separate, now-abandoned diagnostic dead end: a
 * configASSERT self-test in the stock port.c that empirically probes an
 * NVIC priority register and got an all-zero read back, unrelated to any
 * configPRIO_BITS setting).
 */

#ifndef PORTMACRO_H
#define PORTMACRO_H

/* Marker checked by src/port.c: proves THIS header (not the stock one) was used. */
#define PORT_WOKWI_SAFE_MACRO_HEADER 1

/* This header is force-included into every translation unit (see platformio.ini),
 * including the assembly startup file, so hide all C content from the assembler. */
#ifndef __ASSEMBLER__

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------
 * Port specific definitions.
 *----------------------------------------------------------*/

#define portCHAR          char
#define portFLOAT         float
#define portDOUBLE        double
#define portLONG          long
#define portSHORT         short
#define portSTACK_TYPE    uint32_t
#define portBASE_TYPE     long

typedef portSTACK_TYPE   StackType_t;
typedef long             BaseType_t;
typedef unsigned long    UBaseType_t;

#if ( configUSE_16_BIT_TICKS == 1 )
    typedef uint16_t TickType_t;
    #define portMAX_DELAY ( TickType_t ) 0xffff
#else
    typedef uint32_t TickType_t;
    #define portMAX_DELAY ( TickType_t ) 0xffffffffUL
    #define portTICK_TYPE_IS_ATOMIC 1
#endif

/*-----------------------------------------------------------
 * Architecture specifics.
 *----------------------------------------------------------*/

#define portSTACK_GROWTH            ( -1 )
#define portTICK_PERIOD_MS          ( ( TickType_t ) 1000 / configTICK_RATE_HZ )
#define portBYTE_ALIGNMENT          8

/*-----------------------------------------------------------
 * Critical sections -- PRIMASK-based (not BASEPRI: see header comment).
 *----------------------------------------------------------*/

extern void vPortEnterCritical( void );
extern void vPortExitCritical( void );

#define portDISABLE_INTERRUPTS()   __asm volatile ( " cpsid i " ::: "memory" )
#define portENABLE_INTERRUPTS()    __asm volatile ( " cpsie i " ::: "memory" )

#define portENTER_CRITICAL()       vPortEnterCritical()
#define portEXIT_CRITICAL()        vPortExitCritical()

/* ISR-safe interrupt mask save/restore, also PRIMASK-based. */
static inline uint32_t vPortSetInterruptMaskFromISR( void )
{
    uint32_t ulOriginalMask;
    __asm volatile
    (
        " mrs %0, PRIMASK   \n"
        " cpsid i           \n"
        : "=r" ( ulOriginalMask ) :: "memory"
    );
    return ulOriginalMask;
}

static inline void vPortClearInterruptMaskFromISR( uint32_t ulMask )
{
    __asm volatile ( " msr PRIMASK, %0 " :: "r" ( ulMask ) : "memory" );
}

#define portSET_INTERRUPT_MASK_FROM_ISR()          vPortSetInterruptMaskFromISR()
#define portCLEAR_INTERRUPT_MASK_FROM_ISR( x )      vPortClearInterruptMaskFromISR( x )

/*-----------------------------------------------------------
 * Yield / scheduling -- SVC-based, never PendSV.
 *----------------------------------------------------------*/

#define portNVIC_INT_CTRL_REG      ( *( ( volatile uint32_t * ) 0xe000ed04 ) )
#define portNVIC_PENDSVSET_BIT     ( 1UL << 28UL )  /* unused by this port; kept for reference only */

#define portYIELD()                __asm volatile ( " svc 0 " ::: "memory" )
#define portYIELD_WITHIN_API       portYIELD

/* Since SysTick performs tick-driven switches synchronously itself (see
 * port.c), a plain ISR that wants to request a switch after it returns just
 * needs to trigger the same SVC-based path as a normal voluntary yield. */
#define portEND_SWITCHING_ISR( xSwitchRequired )   do { if( ( xSwitchRequired ) != pdFALSE ) { portYIELD(); } } while( 0 )
#define portYIELD_FROM_ISR( x )                    portEND_SWITCHING_ISR( x )

#define portNOP()                  __asm volatile ( " nop " )
#define portINLINE                 __inline

#ifndef portFORCE_INLINE
    #define portFORCE_INLINE inline __attribute__(( always_inline))
#endif

#define portMEMORY_BARRIER()       __asm volatile( "" ::: "memory" )

/*-----------------------------------------------------------
 * Task function macros.
 *----------------------------------------------------------*/

#define portTASK_FUNCTION_PROTO( vFunction, pvParameters )    void vFunction( void *pvParameters )
#define portTASK_FUNCTION( vFunction, pvParameters )          void vFunction( void *pvParameters )

#ifdef __cplusplus
}
#endif

#endif /* __ASSEMBLER__ */

#endif /* PORTMACRO_H */
