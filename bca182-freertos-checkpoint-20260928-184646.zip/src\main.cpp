#include "stm32f1xx_hal.h"

#include <string.h>
#include <stdint.h>

#include "FreeRTOS.h"
#include "task.h"


/* =========================================================
 * UART
 * ========================================================= */

UART_HandleTypeDef huart1;


/* =========================================================
 * STM32 Vector Table
 * ========================================================= */

extern "C" uint32_t g_pfnVectors[];


/* =========================================================
 * Function Prototypes
 * ========================================================= */

void SystemClock_Config(void);

static void MX_USART1_UART_Init(void);

static void Heartbeat_GPIO_Init(void);


/* =========================================================
 * UART PRINT
 * ========================================================= */

static void UartPrint(const char* s)
{
    HAL_UART_Transmit(
        &huart1,
        (uint8_t*)s,
        (uint16_t)strlen(s),
        HAL_MAX_DELAY
    );
}


/* =========================================================
 * UART PRINT UNSIGNED INTEGER
 * ========================================================= */

static void UartPrintUInt(
    const char* label,
    unsigned long val
)
{
    char digits[12];
    int di = 0;

    if (val == 0)
    {
        digits[di++] = '0';
    }

    while (val > 0)
    {
        digits[di++] = '0' + (val % 10);
        val /= 10;
    }

    UartPrint(label);

    char out[16];
    int oi = 0;

    while (di > 0)
    {
        out[oi++] = digits[--di];
    }

    out[oi++] = '\r';
    out[oi++] = '\n';
    out[oi] = '\0';

    UartPrint(out);
}


/* =========================================================
 * FAULT / ASSERT BLINK PATTERN (LED-first, no UART dependency)
 * ========================================================= */

static void FaultBlink_Forever(int pulsesPerCycle)
{
    for (;;)
    {
        for (int i = 0; i < pulsesPerCycle; i++)
        {
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // LED on
            for (volatile int d = 0; d < 100000; d++) {}
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // LED off
            for (volatile int d = 0; d < 100000; d++) {}
        }
        for (volatile int d = 0; d < 800000; d++) {}
    }
}


/* =========================================================
 * HARDFAULT HANDLER
 * ========================================================= */

extern "C" void HardFault_Handler(void) __attribute__((naked));
extern "C" void HardFault_Handler(void)
{
    __asm volatile
    (
        " tst lr, #4                \n"
        " ite eq                    \n"
        " mrseq r0, msp             \n"
        " mrsne r0, psp             \n"
        " b hard_fault_handler_c    \n"
    );
}


/* =========================================================
 * HARDFAULT C HANDLER
 * ========================================================= */

extern "C" void hard_fault_handler_c(unsigned long *stack)
{
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // LED on: confirms entry

    unsigned long pc = stack[6];
    unsigned long lr = stack[5];
    unsigned long cfsr = *(volatile unsigned long*)0xE000ED28;
    unsigned long hfsr = *(volatile unsigned long*)0xE000ED2C;

    (void)pc;
    (void)lr;

    // Pure-GPIO diagnostic -- no UART, no HAL calls that could themselves
    // hang. Decode which fault sub-register fired via blink count so we
    // get an answer even if UART is completely wedged.
    uint8_t mmfsr = (uint8_t)(cfsr & 0xFF);         // MemManage fault status
    uint8_t bfsr  = (uint8_t)((cfsr >> 8) & 0xFF);  // Bus fault status
    uint16_t ufsr = (uint16_t)((cfsr >> 16) & 0xFFFF); // Usage fault status

    int blinkCode;
    if (ufsr != 0)      blinkCode = 3; // Usage fault (bad instruction, unaligned, div0, etc.)
    else if (bfsr != 0) blinkCode = 2; // Bus fault (bad memory access)
    else if (mmfsr != 0) blinkCode = 1; // MemManage fault
    else                 blinkCode = 5; // No sub-status set -- forced/escalated fault

    for (;;)
    {
        for (int i = 0; i < blinkCode; i++)
        {
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // on
            for (volatile int d = 0; d < 300000; d++) {}
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // off
            for (volatile int d = 0; d < 300000; d++) {}
        }
        for (volatile int d = 0; d < 2000000; d++) {} // long pause between cycles

        // Best-effort UART attempt after the GPIO pattern has already run
        // at least once, in case UART actually does still work and we
        // just needed to see the GPIO proof first.
        UartPrint("\r\n[HARDFAULT] PC=");
        UartPrintUInt("", pc);
        UartPrint("[HARDFAULT] LR=");
        UartPrintUInt("", lr);
        UartPrint("[HARDFAULT] CFSR=");
        UartPrintUInt("", cfsr);
        UartPrint("[HARDFAULT] HFSR=");
        UartPrintUInt("", hfsr);
    }
}


/* =========================================================
 * ASSERT HANDLER (required by configASSERT in FreeRTOSConfig.h)
 * Safe to use now -- see FreeRTOSConfig.h for why.
 * ========================================================= */

extern "C" void vAssertCalled(const char* file, int line)
{
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

    UartPrint("\r\n[ASSERT FAILED] ");
    UartPrint(file);
    UartPrint(" line: ");
    UartPrintUInt("", (unsigned long)line);

    for (;;) {} // solid ON = confirmed assert entry
}


/* =========================================================
 * STACK OVERFLOW HOOK
 * ========================================================= */

extern "C" void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    (void)xTask;
    (void)pcTaskName;

    UartPrint("\r\n[ERROR: STACK OVERFLOW DETECTED!]\r\n");
    FaultBlink_Forever(6); // 6 fast blinks per cycle = stack overflow
}


/* =========================================================
 * IDLE HOOK -- LED heartbeat proves the scheduler/idle task is alive
 * ========================================================= */

extern "C" void vApplicationIdleHook(void)
{
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
    for (volatile int i = 0; i < 200000; i++) {}
}


/* =========================================================
 * HAL TICK
 *
 * TIM4 = HAL tick
 * SysTick = FreeRTOS tick
 * ========================================================= */

extern "C" HAL_StatusTypeDef HAL_InitTick(uint32_t TickPriority)
{
    __HAL_RCC_TIM4_CLK_ENABLE();

    TIM4->PSC = 7;      // 8 MHz / 8 = 1 MHz timer clock
    TIM4->ARR = 999;    // 1 MHz / 1000 = 1 kHz -> 1 ms tick
    TIM4->CNT = 0;
    TIM4->DIER |= TIM_DIER_UIE;
    TIM4->CR1 |= TIM_CR1_CEN;

    HAL_NVIC_SetPriority(TIM4_IRQn, TickPriority, 0);
    HAL_NVIC_EnableIRQ(TIM4_IRQn);

    return HAL_OK;
}


/* =========================================================
 * TIM4 IRQ HANDLER
 * ========================================================= */

extern "C" void TIM4_IRQHandler(void)
{
    if (TIM4->SR & TIM_SR_UIF)
    {
        TIM4->SR &= ~TIM_SR_UIF;
        HAL_IncTick();
    }
}


/* =========================================================
 * TASK A -- Period: 1000 ms, Priority: 1
 * ========================================================= */

void TaskA(void *pvParameters)
{
    (void)pvParameters;

    for (;;)
    {
        UartPrintUInt("Task A running @tick ", (unsigned long)xTaskGetTickCount());
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}


/* =========================================================
 * TASK B -- Period: 1500 ms, Priority: 1
 * ========================================================= */

void TaskB(void *pvParameters)
{
    (void)pvParameters;

    for (;;)
    {
        UartPrintUInt("Task B running @tick ", (unsigned long)xTaskGetTickCount());
        vTaskDelay(pdMS_TO_TICKS(1500));
    }
}


/* =========================================================
 * MAIN
 * ========================================================= */

int main(void)
{
    HAL_Init();

    SystemClock_Config();

    HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

    SCB->VTOR = (uint32_t)g_pfnVectors;
    __DSB();
    __ISB();

    MX_USART1_UART_Init();

    Heartbeat_GPIO_Init();

    UartPrint(
        "BCA182 FreeRTOS Multisensor\r\n"
        "System starting...\r\n"
    );

    UartPrintUInt("Free heap before create: ", (unsigned long)xPortGetFreeHeapSize());

    BaseType_t okA = xTaskCreate(TaskA, "TaskA", 512, NULL, 1, NULL);
    UartPrintUInt("TaskA create result: ", (unsigned long)okA);

    BaseType_t okB = xTaskCreate(TaskB, "TaskB", 512, NULL, 1, NULL);
    UartPrintUInt("TaskB create result: ", (unsigned long)okB);

    UartPrintUInt("Free heap after create: ", (unsigned long)xPortGetFreeHeapSize());

    UartPrint("Calling vTaskStartScheduler()...\r\n");

    vTaskStartScheduler();

    UartPrint("!!! Scheduler start FAILED (returned) !!!\r\n");

    while (1) {}
}


/* =========================================================
 * GPIO INITIALIZATION
 * ========================================================= */

static void Heartbeat_GPIO_Init(void)
{
    __HAL_RCC_GPIOC_CLK_ENABLE();

    GPIO_InitTypeDef gi = {0};
    gi.Pin = GPIO_PIN_13;
    gi.Mode = GPIO_MODE_OUTPUT_PP;
    gi.Speed = GPIO_SPEED_FREQ_LOW;

    HAL_GPIO_Init(GPIOC, &gi);

    // Explicitly force OFF (active-low LED: SET = off). Without this, the
    // pin sits at its post-reset default level (0 = LED ON) regardless of
    // whether anything in our code ever runs -- making "solid ON" an
    // ambiguous, untrustworthy signal. Now: OFF at boot, and it only
    // changes if the idle hook (blinking = scheduler alive) or the fault
    // handler (solid ON = genuinely entered a fault) actually executes.
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
}


/* =========================================================
 * SYSTEM CLOCK CONFIGURATION -- HSI 8 MHz, PLL disabled
 * ========================================================= */

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
}


/* =========================================================
 * USART1 INITIALIZATION -- PA9=TX, PA10=RX, 115200 baud
 * ========================================================= */

static void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart1);
}


/* =========================================================
 * USART1 GPIO INITIALIZATION
 * ========================================================= */

extern "C" void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();

        GPIO_InitStruct.Pin = GPIO_PIN_9;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        GPIO_InitStruct.Pin = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    }
}
