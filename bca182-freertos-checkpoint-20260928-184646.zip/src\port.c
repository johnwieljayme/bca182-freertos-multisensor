/*
 * Custom FreeRTOS Cortex-M3 port for this project -- Wokwi-safe variant.
 *
 * Replaces PlatformIO-FreeRTOS's stock ARM_CM3 port.c (excluded from the
 * build via platformio.ini's build_src_filter). See include/portmacro.h
 * for the full rationale.
 *
 * Design: no PendSV anywhere. Context switches happen synchronously:
 *   - SVC_Handler: first-task launch (no save needed) OR a voluntary
 *     yield from a running task (save + vTaskSwitchContext + restore).
 *   - SysTick_Handler: increments the tick; if a switch is due, performs
 *     the same save + vTaskSwitchContext + restore, synchronously, right
 *     there in the tick handler, instead of merely pending PendSV.
 * Both SVC and SysTick were confirmed (by direct probing) to enter and
 * return correctly under Wokwi's Cortex-M3 emulation; only the PendSV/ICSR
 * self-pend mechanism was found to be broken.
 */

#include "FreeRTOS.h"
#include "task.h"

#ifndef PORT_WOKWI_SAFE_MACRO_HEADER
#error "Stock portmacro.h was picked up instead of include/portmacro.h (PendSV-based, hangs in Wokwi)"
#endif

/* Set to 1 by SVC_Handler the first time it runs (the initial launch).
 * Every SVC entry after that is treated as a voluntary yield needing a
 * full save/switch/restore. */
static volatile uint32_t ulPortFirstTaskStarted = 0;

/* Critical section nesting count (PRIMASK-based; see portmacro.h). */
static volatile UBaseType_t uxCriticalNesting = 0xaaaaaaaa;

#define portINITIAL_XPSR            ( 0x01000000UL )
#define portSTART_ADDRESS_MASK      ( ( StackType_t ) 0xfffffffeUL )

#define portNVIC_SYSTICK_CTRL_REG          ( *( ( volatile uint32_t * ) 0xe000e010 ) )
#define portNVIC_SYSTICK_LOAD_REG          ( *( ( volatile uint32_t * ) 0xe000e014 ) )
#define portNVIC_SYSTICK_CURRENT_VALUE_REG ( *( ( volatile uint32_t * ) 0xe000e018 ) )
#define portNVIC_SYSTICK_CLK_BIT           ( 1UL << 2UL )
#define portNVIC_SYSTICK_INT_BIT           ( 1UL << 1UL )
#define portNVIC_SYSTICK_ENABLE_BIT        ( 1UL << 0UL )

static void prvTaskExitError( void )
{
    /* A task function must never return. */
    volatile uint32_t ulDummy = 0UL;
    portDISABLE_INTERRUPTS();
    while( ulDummy == 0UL )
    {
    }
}

/*-----------------------------------------------------------*/

StackType_t * pxPortInitialiseStack( StackType_t * pxTopOfStack,
                                      TaskFunction_t pxCode,
                                      void * pvParameters )
{
    /* Simulate the stack frame as it would look after an exception entry,
     * exactly as the stock port does -- this part of the mechanism is
     * unaffected by the PendSV bug and needs no change. */
    pxTopOfStack--;
    *pxTopOfStack = portINITIAL_XPSR;
    pxTopOfStack--;
    *pxTopOfStack = ( ( StackType_t ) pxCode ) & portSTART_ADDRESS_MASK;
    pxTopOfStack--;
    *pxTopOfStack = ( StackType_t ) prvTaskExitError;
    pxTopOfStack -= 5; /* R12, R3, R2, R1 (and one more slot to match layout). */
    *pxTopOfStack = ( StackType_t ) pvParameters; /* R0 */
    pxTopOfStack -= 8; /* R11..R4 */

    return pxTopOfStack;
}

/*-----------------------------------------------------------*/

/* Wokwi's Cortex-M3 model does NOT mask SysTick when PRIMASK is set, so a
 * plain cpsid/cpsie critical section is not atomic against the tick: the tick
 * handler (which here also performs context switches) can fire in the middle
 * of the kernel's list manipulation and corrupt the ready/delayed lists.
 * So critical sections also gate the SysTick interrupt enable bit (TICKINT),
 * which was observed to stop the tick cleanly.
 *
 * Known limitation: a tick boundary that passes while gated is not replayed,
 * so the tick count can lose a few ms over long runs. Acceptable for this lab;
 * critical sections are only a few microseconds long. */
void vPortEnterCritical( void )
{
    portDISABLE_INTERRUPTS();
    portNVIC_SYSTICK_CTRL_REG &= ~portNVIC_SYSTICK_INT_BIT;
    uxCriticalNesting++;
}

void vPortExitCritical( void )
{
    uxCriticalNesting--;
    if( uxCriticalNesting == 0 )
    {
        portNVIC_SYSTICK_CTRL_REG |= portNVIC_SYSTICK_INT_BIT;
        portENABLE_INTERRUPTS();
    }
}

/*-----------------------------------------------------------*/

/* First-launch + voluntary-yield handler. Naked: we manage every register
 * by hand and return via a raw exception-return branch, so no
 * compiler-generated prologue/epilogue may run. */
void SVC_Handler( void ) __attribute__( ( naked ) );
void SVC_Handler( void )
{
    __asm volatile
    (
    "   ldr  r3, =ulPortFirstTaskStarted   \n"
    "   ldr  r2, [r3]                      \n"
    "   cmp  r2, #0                        \n"
    "   bne  svc_switch_context            \n"
    "                                      \n"
    "svc_first_launch:                     \n"
    "   movs r2, #1                        \n"
    "   str  r2, [r3]                      \n"
    "   ldr  r3, =pxCurrentTCB             \n"
    "   ldr  r1, [r3]                      \n"
    "   ldr  r0, [r1]                      \n"
    "   ldmia r0!, {r4-r11}                \n"
    "   msr  psp, r0                       \n"
    "   isb                                \n"
    "   orr  r14, #0xd                     \n"
    "   bx   r14                           \n"
    "                                      \n"
    "svc_switch_context:                   \n"
    "   mrs  r0, psp                       \n"
    "   isb                                \n"
    "   ldr  r3, =pxCurrentTCB             \n"
    "   ldr  r2, [r3]                      \n"
    "   stmdb r0!, {r4-r11}                \n"
    "   str  r0, [r2]                      \n"
    "   stmdb sp!, {r3, r14}               \n"
    "   bl   vTaskSwitchContext            \n"
    "   ldmia sp!, {r3, r14}               \n"
    "   ldr  r1, [r3]                      \n"
    "   ldr  r0, [r1]                      \n"
    "   ldmia r0!, {r4-r11}                \n"
    "   msr  psp, r0                       \n"
    "   isb                                \n"
    "   bx   r14                           \n"
    "   .ltorg                             \n"
    );
}

/*-----------------------------------------------------------*/

/* Tick handler: always increments the tick; if that indicates a switch is
 * due, performs it synchronously right here instead of pending PendSV. */
void SysTick_Handler( void ) __attribute__( ( naked ) );
void SysTick_Handler( void )
{
    __asm volatile
    (
    "   push {r0, lr}                      \n"
    "   bl   xTaskIncrementTick             \n"
    "   cmp  r0, #0                         \n"
    "   pop  {r0, lr}                       \n"
    "   beq  systick_no_switch              \n"
    "                                       \n"
    "   mrs  r0, psp                        \n"
    "   isb                                 \n"
    "   ldr  r3, =pxCurrentTCB              \n"
    "   ldr  r2, [r3]                       \n"
    "   stmdb r0!, {r4-r11}                 \n"
    "   str  r0, [r2]                       \n"
    "   stmdb sp!, {r3, r14}                \n"
    "   bl   vTaskSwitchContext             \n"
    "   ldmia sp!, {r3, r14}                \n"
    "   ldr  r1, [r3]                       \n"
    "   ldr  r0, [r1]                       \n"
    "   ldmia r0!, {r4-r11}                 \n"
    "   msr  psp, r0                        \n"
    "   isb                                 \n"
    "                                       \n"
    "systick_no_switch:                     \n"
    "   bx   lr                             \n"
    "   .ltorg                              \n"
    );
}

/*-----------------------------------------------------------*/

static void prvPortStartFirstTask( void ) __attribute__( ( naked ) );
static void prvPortStartFirstTask( void )
{
    __asm volatile
    (
    " ldr r0, =0xE000ED08   \n"
    " ldr r0, [r0]          \n"
    " ldr r0, [r0]          \n"
    " msr msp, r0           \n"
    " cpsie i                \n"
    " dsb                    \n"
    " isb                    \n"
    " svc 0                  \n"
    " nop                    \n"
    " .ltorg                 \n"
    );
}

/*-----------------------------------------------------------*/

void vPortSetupTimerInterrupt( void )
{
    portNVIC_SYSTICK_CTRL_REG = 0UL;
    portNVIC_SYSTICK_CURRENT_VALUE_REG = 0UL;
    portNVIC_SYSTICK_LOAD_REG = ( configCPU_CLOCK_HZ / configTICK_RATE_HZ ) - 1UL;
    portNVIC_SYSTICK_CTRL_REG = ( portNVIC_SYSTICK_CLK_BIT | portNVIC_SYSTICK_INT_BIT | portNVIC_SYSTICK_ENABLE_BIT );
}

/*-----------------------------------------------------------*/

BaseType_t xPortStartScheduler( void )
{
    /* Deliberately no PendSV/SVC vector-table verification, and no
     * BASEPRI-derived priority-bit self-test here: this port doesn't rely
     * on either mechanism, and the priority-bit probe was found to read
     * back all-zero from Wokwi's simulated NVIC regardless of any
     * configPRIO_BITS value, independent of the actual bug -- so it isn't
     * a meaningful check to run here anyway. */

    vPortSetupTimerInterrupt();

    uxCriticalNesting = 0;
    ulPortFirstTaskStarted = 0;

    prvPortStartFirstTask();

    /* Should never reach here. */
    prvTaskExitError();
    return 0;
}

/*-----------------------------------------------------------*/

void vPortEndScheduler( void )
{
    /* Not supported. */
    for( ;; )
    {
    }
}
